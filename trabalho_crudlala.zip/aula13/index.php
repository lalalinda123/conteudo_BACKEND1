<?php 
header("Location: site/index.php");
//fim da aula 13 <33333333
?>


