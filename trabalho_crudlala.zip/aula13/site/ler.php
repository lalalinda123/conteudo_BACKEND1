<?php
    include_once "../template/cabecalho.php";
    include_once "../template/menu.php";
    include_once "../receitas/consultar_por_id.php";
?>

<div class="container">
    <h1><?php echo $receitas->nome; ?></h1>
    <hr>
    <img src="../uploads/<?php echo $receitas->foto; ?>" class="" />
    <p><?php echo $receitas->ingrediente; ?></p>
</div>
<?php include_once "../template/rodape.php"; ?>