<?php
    include_once "../receitas/consultar_todos.php";
   include_once "../template/cabecalho.php";
    include_once "../template/menu.php";
?>
<!-- Receitas -->
<div class="container">

  <div class="row row-cols-1 row-cols-md-2 g-4">

    <?php 
    
    foreach($receitas as $receita): 
      
    ?>
    <div class="col">
      <div class="card">
        <img src="../uploads/<?php echo $receita->foto; ?>" class="card-img-top" alt="...">
        <div class="card-body">
            <h5 class="card-title"><?php echo $receita->nome; ?></h5>
            <a href="ler.php?id=<?php echo $receita->idreceitas; ?>" class="btn btn-primary">Ler mais</a>
        </div>
      </div>
    </div>

    <?php endforeach; ?>
  </div>

</div>
<!-- Final das Receitas --> 
<?php
include_once "../template/rodape.php";
?>