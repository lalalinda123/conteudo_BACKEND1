<?php
   //importa o arquivo de conexão
   require_once "../banco/conexao.php";

   //cria uma variável com um comando SQL
   $SQL = "SELECT * FROM receitas";
 
   //prepara o comando para ser executado no mysql
   $comando = $conexao->prepare($SQL);

   $comando->execute();

   //pegar os resultados da consulta
   $resultados = $comando->get_result(); 

   //pega todas as linhas do resultado da consulta
   $receitas = [];
   while ($receita = $resultados->fetch_object()){
      $receitas[] = $receita; 
   }


   ?>