<?php 
require_once "consultar_por_id.php";
require_once "../template/cabecalho.php";
?>
<div class="container">
    <h1>Cadastro de receitas</h1>
    <hr>

    <form action="<?php echo isset($receitas) ? 
     "atualizar.php":
     "inserir.php"; ?>"
      method="post" enctype="multipart/form-data">
        
        <input type="hidden" name="idreceitas" value="<?php echo $receitas->idreceitas ?? "" ;?>" ><br>

        <label class="form-label">Nome</label><br>
        <input class="form-control" type="text" name="nome" value="<?php echo $receitas->nome ?? "" ;?>" ><br>

        <label class="form-label">Ingrediente</label><br>
        <textarea class="form-control" name="ingrediente"><?php echo $receitas->ingredientes ?? "" ;?></textarea><br>

        <label class="form-label">Modo preparo</label><br>
        <textarea class="form-control" name="modopreparo" ><?php echo $receitas->modopreparo ?? "" ;?></textarea><br>

        <label class="form-label">Tempo preparo</label><br>
        <input class="form-control" type="text" name="tempopreparo" value="<?php echo $receitas->tempopreparo ?? "" ;?>" ><br>

        <label class="form-label">foto</label><br>
        <input class="form-control" type="file" name="foto"><br>
        <br>
        <button type="submit" class="btn btn-info">Inserir</button>
    </form>
    
</div>

    <?php require_once "../template/rodape.php" ?>

    