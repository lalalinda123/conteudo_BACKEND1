<?php
   
   //importa o arquivo de conexão
   require_once "../banco/conexao.php";

   if(isset($_POST['nome'])){

      //faz upload da foto do usuário
      require_once "faz_upload.php";

   $nome = $_POST['nome'];
   $ingrediente = $_POST['ingrediente'];
   $modopreparo = $_POST['modopreparo'];
   $tempopreparo = $_POST['tempopreparo'];
   $foto = $nome_foto; 

   //cria uma variável com um comando SQL
   echo $SQL = "INSERT INTO `receitas` (`nome`, `ingredientes`, `modopreparo`, `tempopreparo`, foto) VALUES (?, ?, ?, ?, ?);";
 
   //prepara o comando para ser executado no mysql
   $comando = $conexao->prepare($SQL);

   //faz a vinculação dos parâmetros ?, ?, ?
   $comando->bind_param("sssss", $nome, $ingrediente, $modopreparo, $tempopreparo, $foto);

   //executa o comando
   $comando->execute();

}
   //volta para o formulário
   header("Location: index.php");

   







